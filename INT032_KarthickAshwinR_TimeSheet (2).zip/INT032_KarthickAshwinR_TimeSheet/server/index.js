import express from 'express';
import fs from 'fs'
import cors from 'cors';
const app = express();

const FILEPATH = "data.json"


app.use(cors());
app.use(express.json())


app.get('/', (req, res) => {
    res.send(`
        <h1>This is Simple expressJS API.</h1>
        <p> It's a index page</p>
    `)
})


// {payload: {bauRows:"[]", salesRows: "[]"}}
app.post('/timesheet', (req, res) => {
    const { payload } = req.body;
    fs.writeFileSync(FILEPATH, JSON.stringify(payload));

    return res.json({ message: "Data Successfully saved!" })
})

app.get('/timesheet', (req, res) => {
    const payloadJSON = fs.readFileSync(FILEPATH);
    const payload = JSON.parse(payloadJSON);
    return res.json({ payload: payload, message: "Payload sent!" })

})

app.delete("/timesheet", (req, res) => {
    const payload = {
        bauRows: [],
        salesRows: []
    };

    const payloadJSON = JSON.stringify(payload);

    fs.writeFileSync(FILEPATH, payloadJSON)
    return res.json({ message: "Payload Reseted!" })
})

// app.patch("/timesheet", (req, res) => {

// })


const PORT = 3000;
app.listen(PORT, () => {
    console.log(`The app started on ${PORT}. Visit http://localhost:${PORT}/`)
})