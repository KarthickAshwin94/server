import axios from 'axios';

const URL = "http://localhost:3000/timesheet"
export const saveData = async (payload) => {

    let response;

    try {
        response = await axios.post(URL, payload);
    } catch (error) {
        console.log(error.message)
    }
    return response;
}


export const getData = async () => {
    let response = [];
    try {
        response = await axios.get(URL);
    } catch (error) {
        console.log(error)
    }

    return response;
}

export const deleteData = async () => {

    let response;
    try {
        response = await axios.delete(URL);
    } catch (error) {
        console.log(error.message)
    }

    return response;
}